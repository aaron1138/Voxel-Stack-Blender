# operations_registry.py

from dataclasses import dataclass, field
from typing import List, Optional, Union, Callable, Dict, Any
import lut_manager # Keep this if LUT_GENERATOR_FUNCTIONS uses lut_manager functions directly.

# REMOVE: import xy_blend_processor


# --- Data Classes for Pipeline Operations ---
# These were moved here from config.py to co-locate with the operation definitions.

@dataclass
class LutParameters:
    """
    Parameters for generating or loading a Look-Up Table (LUT).
    These parameters will be nested within an XYBlendOperation of type 'apply_lut'.
    """
    lut_source: str = "generated"
    
    # Parameters for 'generated' LUTs
    lut_generation_type: str = "linear"
    gamma_value: float = 1.0
    linear_min_input: int = 0
    linear_max_output: int = 255
    s_curve_contrast: float = 0.5
    log_param: float = 10.0
    exp_param: float = 2.0
    sqrt_param: float = 1.0
    rodbard_param: float = 1.0

    # Parameters for 'file' LUTs
    fixed_lut_path: str = ""

    def __post_init__(self):
        # Ensure values are within sensible bounds after loading/setting
        self.lut_source = self.lut_source.lower()
        self.lut_generation_type = self.lut_generation_type.lower()
        self.gamma_value = max(0.01, self.gamma_value)
        self.linear_min_input = max(0, min(255, self.linear_min_input))
        self.linear_max_output = max(0, min(255, self.linear_max_output)) # This line has a potential bug, see notes below
        self.s_curve_contrast = max(0.0, min(1.0, self.s_curve_contrast))
        self.log_param = max(0.01, self.log_param)
        self.exp_param = max(0.01, self.exp_param)
        self.sqrt_param = max(0.01, self.sqrt_param)
        self.rodbard_param = max(0.01, self.rodbard_param)


@dataclass
class XYBlendOperation:
    """
    Represents a single operation in the XY image processing pipeline.
    Parameters for each operation type are defined here.
    """
    type: str = "none"

    gaussian_ksize_x: int = 3
    gaussian_ksize_y: int = 3
    gaussian_sigma_x: float = 0.0
    gaussian_sigma_y: float = 0.0

    bilateral_d: int = 9
    bilateral_sigma_color: float = 75.0
    bilateral_sigma_space: float = 75.0

    median_ksize: int = 5

    unsharp_amount: float = 1.0
    unsharp_threshold: int = 0
    unsharp_blur_ksize: int = 5
    unsharp_blur_sigma: float = 0.0

    resize_width: Optional[int] = None
    resize_height: Optional[int] = None
    resample_mode: str = "LANCZOS4"

    lut_params: LutParameters = field(default_factory=LutParameters)

    def __post_init__(self):
        self.type = self.type.lower()
        if self.type in ["gaussian_blur", "median_blur", "unsharp_mask"]:
            if self.type == "gaussian_blur":
                self.gaussian_ksize_x = self._ensure_odd_positive_ksize(self.gaussian_ksize_x)
                self.gaussian_ksize_y = self._ensure_odd_positive_ksize(self.gaussian_ksize_y)
            elif self.type == "median_blur":
                self.median_ksize = self._ensure_odd_positive_ksize(self.median_ksize)
            elif self.type == "unsharp_mask":
                self.unsharp_blur_ksize = self._ensure_odd_positive_ksize(self.unsharp_blur_ksize)

        if self.type == "resize":
            if self.resize_width is not None:
                self.resize_width = max(0, self.resize_width)
            if self.resize_height is not None:
                self.resize_height = max(0, self.resize_height)
            if self.resize_width == 0: self.resize_width = None
            if self.resize_height == 0: self.resize_height = None

    def _ensure_odd_positive_ksize(self, ksize: int) -> int:
        if ksize <= 0:
            return 1
        return ksize if ksize % 2 != 0 else ksize + 1


# --- Param Definition Maps for UI Widgets ---
# This dictionary maps parameter names to their UI configuration.
# This makes the UI building process generic and dynamic.
PARAM_DEFINITIONS = {
    "gaussian_ksize_x": {"label": "Kernel Size X", "type": int, "default": 3},
    "gaussian_ksize_y": {"label": "Kernel Size Y", "type": int, "default": 3},
    "gaussian_sigma_x": {"label": "Sigma X", "type": float, "default": 0.0},
    "gaussian_sigma_y": {"label": "Sigma Y", "type": float, "default": 0.0},
    "bilateral_d": {"label": "Diameter", "type": int, "default": 9},
    "bilateral_sigma_color": {"label": "Sigma Color", "type": float, "default": 75.0},
    "bilateral_sigma_space": {"label": "Sigma Space", "type": float, "default": 75.0},
    "median_ksize": {"label": "Kernel Size", "type": int, "default": 5},
    "unsharp_amount": {"label": "Amount", "type": float, "default": 1.0},
    "unsharp_threshold": {"label": "Threshold", "type": int, "default": 0},
    "unsharp_blur_ksize": {"label": "Blur Ksize", "type": int, "default": 5},
    "unsharp_blur_sigma": {"label": "Blur Sigma", "type": float, "default": 0.0},
    "resize_width": {"label": "Width", "type": int, "default": 0, "allow_none_if_zero": True},
    "resize_height": {"label": "Height", "type": int, "default": 0, "allow_none_if_zero": True},
    "resample_mode": {"label": "Mode", "type": str, "choices": ["NEAREST", "BILINEAR", "BICUBIC", "LANCZOS4", "AREA"], "default": "LANCZOS4"},
    
    # LUT Params
    "lut_source": {"label": "LUT Source", "type": str, "choices": ["Generated", "File"], "default": "Generated"},
    "lut_generation_type": {"label": "Generation Type", "type": str, "choices": ["Linear", "Gamma", "S_curve", "Log", "Exp", "Sqrt", "Rodbard"], "default": "Linear"},
    "lut_filepath_edit": {"label": "File Path", "type": str, "is_file_path": True, "default": ""},
    "lut_linear_min_input": {"label": "Min Input", "type": int, "default": 0},
    "lut_linear_max_output": {"label": "Max Output", "type": int, "default": 255},
    "lut_gamma_value": {"label": "Gamma", "type": float, "default": 1.0, "slider": {"min": 1, "max": 200, "scale_factor": 100}},
    "lut_s_curve_contrast": {"label": "Contrast", "type": float, "default": 0.5, "slider": {"min": 0, "max": 100, "scale_factor": 100}},
    "lut_log_param": {"label": "Log Param", "type": float, "default": 10.0, "slider": {"min": 1, "max": 100, "scale_factor": 10}},
    "lut_exp_param": {"label": "Exp Param", "type": float, "default": 2.0, "slider": {"min": 1, "max": 100, "scale_factor": 100}},
    "lut_sqrt_param": {"label": "Sqrt Param", "type": float, "default": 1.0}, # Added slider for consistency
    "lut_rodbard_param": {"label": "Rodbard Param", "type": float, "default": 1.0}, # Added slider for consistency
}

# Add slider definitions to sqrt_param and rodbard_param if they are meant to have sliders
PARAM_DEFINITIONS["lut_sqrt_param"]["slider"] = {"min": 1, "max": 200, "scale_factor": 100}
PARAM_DEFINITIONS["lut_rodbard_param"]["slider"] = {"min": 1, "max": 200, "scale_factor": 100}


# --- LUT Generation Function Map ---
# This dictionary maps the LUT generation type string to its corresponding lut_manager function.
LUT_GENERATOR_FUNCTIONS = {
    "linear": lut_manager.generate_linear_lut,
    "gamma": lut_manager.generate_gamma_lut,
    "s_curve": lut_manager.generate_s_curve_lut,
    "log": lut_manager.generate_log_lut,
    "exp": lut_manager.generate_exp_lut,
    "sqrt": lut_manager.generate_sqrt_lut,
    "rodbard": lut_manager.generate_rodbard_lut,
}


# --- Main Operation Registry ---
# This is the single source of truth for the entire pipeline.
# It maps operation type strings to a dictionary of their properties.
OPERATIONS_REGISTRY = {
    "none": {
        "display_name": "No Operation",
        "processor_func_name": None, # Store the function name as a string
        "params": [],
    },
    "gaussian_blur": {
        "display_name": "Gaussian Blur",
        "processor_func_name": "apply_gaussian_blur", # Store as string
        "params": ["gaussian_ksize_x", "gaussian_ksize_y", "gaussian_sigma_x", "gaussian_sigma_y"],
    },
    "bilateral_filter": {
        "display_name": "Bilateral Filter",
        "processor_func_name": "apply_bilateral_filter", # Store as string
        "params": ["bilateral_d", "bilateral_sigma_color", "bilateral_sigma_space"],
    },
    "median_blur": {
        "display_name": "Median Blur",
        "processor_func_name": "apply_median_blur", # Store as string
        "params": ["median_ksize"],
    },
    "unsharp_mask": {
        "display_name": "Unsharp Mask",
        "processor_func_name": "apply_unsharp_mask", # Store as string
        "params": ["unsharp_amount", "unsharp_threshold", "unsharp_blur_ksize", "unsharp_blur_sigma"],
    },
    "resize": {
        "display_name": "Resize",
        "processor_func_name": "apply_resize", # Store as string
        "params": ["resize_width", "resize_height", "resample_mode"],
    },
    "apply_lut": {
        "display_name": "Apply LUT",
        "processor_func_name": "apply_lut_operation", # Store as string
        "params": ["lut_source", "lut_generation_type"],
        "sub_params": {
            "generated": {
                "sub_type_param": "lut_generation_type",
                "types": {
                    "linear": ["lut_linear_min_input", "lut_linear_max_output"],
                    "gamma": ["lut_gamma_value"],
                    "s_curve": ["lut_s_curve_contrast"],
                    "log": ["lut_log_param"],
                    "exp": ["lut_exp_param"],
                    "sqrt": ["lut_sqrt_param"],
                    "rodbard": ["lut_rodbard_param"],
                }
            },
            "file": {
                "params": ["lut_filepath_edit"]
            }
        }
    },
}

# Helper to get the display name from the operation type
def get_op_display_name(op_type: str) -> str:
    return OPERATIONS_REGISTRY.get(op_type, {}).get("display_name", op_type)

# Helper to get all available operation display names
def get_all_op_display_names() -> List[str]:
    return [OPERATIONS_REGISTRY[op_type]["display_name"] for op_type in OPERATIONS_REGISTRY]

# Helper to get a parameter's properties
def get_param_definition(param_name: str) -> Optional[Dict[str, Any]]:
    return PARAM_DEFINITIONS.get(param_name)