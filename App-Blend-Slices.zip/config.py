# config.py (Refactored)

from dataclasses import dataclass, field, asdict, fields
from typing import List, Optional, Union, Any
import json
import os
import copy
from operations_registry import XYBlendOperation, LutParameters # NEW: Import from registry

# Define a sensible default for thread count, using system core count
DEFAULT_NUM_WORKERS = max(1, os.cpu_count() - 1)

@dataclass
class Config:
    """
    Main application configuration.
    This dataclass will hold all settings for the program.
    """
    # General Processing Core Settings
    n_layers: int = 3
    start_index: Optional[int] = 0
    stop_index: Optional[int] = None
    debug_save: bool = False
    thread_count: int = DEFAULT_NUM_WORKERS

    # Receding Gradient Settings
    use_fixed_norm: bool = False
    fixed_fade_distance: float = 10.0

    # Output File Naming
    output_prefix: str = "processed_" # NEW: Output filename prefix
    padding_digits: int = 5          # NEW: Number of digits for padding

    # Input/Output Folders
    input_folder: str = ""
    output_folder: str = ""

    # XY Blend Pipeline (list of operations)
    xy_blend_pipeline: List[XYBlendOperation] = field(default_factory=lambda: [XYBlendOperation("none")])

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Config":
        config_instance = cls()
        
        field_map = {f.name: f for f in fields(cls)}

        for key, value in data.items():
            if key in field_map:
                field_obj = field_map[key]
                
                if key == 'xy_blend_pipeline':
                    pipeline_list = []
                    for op_data in value:
                        op_field_names = {f.name for f in fields(XYBlendOperation)}
                        filtered_op_data = {k: v for k, v in op_data.items() if k in op_field_names}
                        
                        if 'lut_params' in filtered_op_data and isinstance(filtered_op_data['lut_params'], dict):
                            lut_field_names = {f.name for f in fields(LutParameters)}
                            filtered_lut_data = {k: v for k, v in filtered_op_data['lut_params'].items() if k in lut_field_names}
                            filtered_op_data['lut_params'] = LutParameters(**filtered_lut_data)
                        
                        pipeline_list.append(XYBlendOperation(**filtered_op_data))
                    setattr(config_instance, key, pipeline_list)
                else:
                    if field_obj.type is bool and isinstance(value, str):
                        value = value.lower() in ('true', '1', 't', 'y')
                    
                    try:
                        setattr(config_instance, key, value)
                    except (TypeError, ValueError) as e:
                        print(f"Warning: Failed to assign value '{value}' to field '{key}' (expected type {field_obj.type}). Error: {e}. Using default.")
            else:
                print(f"Warning: Unrecognized config key '{key}' found in loaded data. Skipping.")
        return config_instance

    def save(self, filepath: str):
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=4)

    @classmethod
    def load(cls, filepath: str) -> "Config":
        if not os.path.exists(filepath):
            print(f"Config file not found: {filepath}. Creating default config and saving it.")
            default_config = cls()
            try:
                default_config.save(filepath)
            except Exception as e:
                print(f"Error saving default config to {filepath}: {e}")
            return default_config
        
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            return cls.from_dict(data)
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON from config file '{filepath}': {e}. Using default config.")
            return cls()
        except Exception as e:
            print(f"An unexpected error occurred loading config from '{filepath}': {e}. Using default config.")
            return cls()

_CONFIG_FILE = "app_config.json"
app_config = Config.load(_CONFIG_FILE)