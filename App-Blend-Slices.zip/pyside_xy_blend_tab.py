# pyside_xy_blend_tab.py (Corrected and Audited)

import os
from typing import Optional, List, Dict, Any, Callable
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QComboBox,
    QStackedWidget, QLineEdit, QLabel, QMessageBox, QFileDialog, QSlider, QFrame
)
from PySide6.QtCore import Qt, Signal
import numpy as np

# matplotlib imports
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

from config import Config
from operations_registry import (
    OPERATIONS_REGISTRY,
    PARAM_DEFINITIONS,
    LUT_GENERATOR_FUNCTIONS,
    get_all_op_display_names,
    get_op_display_name,
)
import lut_manager # Needed for _plot_current_lut_preview logic

class XYBlendTab(QWidget):
    # Signals for UI events
    operation_changed = Signal()
    config_updated = Signal()

    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        # Stores references to QWidget instances for parameters by their param_name
        self._param_widgets: Dict[str, QWidget] = {} 
        # Stores references to QSlider instances for parameters by their param_name (e.g., "gamma_value_slider")
        self._slider_widgets: Dict[str, QSlider] = {} # NEW: Separate dictionary for sliders for clarity and easier lookup
        
        self.layout = QVBoxLayout(self)

        # Matplotlib Figure for LUT Preview
        self.figure = Figure(figsize=(5, 4), tight_layout=True)
        self.canvas = FigureCanvas(self.figure)
        self.axes = self.figure.add_subplot(111)
        self.layout.addWidget(self.canvas)

        # Main horizontal layout for operation list and controls
        self.h_layout = QHBoxLayout()
        self.layout.addLayout(self.h_layout)

        # Left side: Operation List
        self.ops_list_widget = QListWidget()
        self.ops_list_widget.setDragDropMode(QListWidget.InternalMove)
        self.ops_list_widget.model().rowsMoved.connect(self._reorder_operations_in_config)
        self.ops_list_widget.currentRowChanged.connect(self._update_selected_operation_details)
        self.h_layout.addWidget(self.ops_list_widget, 1)

        # Middle: Control Buttons
        self.btn_layout = QVBoxLayout()
        self.btn_add_op = QPushButton("Add")
        self.btn_add_op.clicked.connect(self._add_operation)
        self.btn_remove_op = QPushButton("Remove")
        self.btn_remove_op.clicked.connect(self._remove_operation)
        self.btn_move_up = QPushButton("Up")
        self.btn_move_up.clicked.connect(self._move_operation_up)
        self.btn_move_down = QPushButton("Down")
        self.btn_move_down.clicked.connect(self._move_operation_down)
        self.btn_layout.addWidget(self.btn_add_op)
        self.btn_layout.addWidget(self.btn_remove_op)
        self.btn_layout.addStretch()
        self.btn_layout.addWidget(self.btn_move_up)
        self.btn_layout.addWidget(self.btn_move_down)
        self.h_layout.addLayout(self.btn_layout)

        # Right side: Parameter controls for selected operation
        self.params_group_widget = QWidget()
        self.params_layout = QVBoxLayout(self.params_group_widget)
        self.h_layout.addWidget(self.params_group_widget, 2)
        
        # Dropdown to select operation type
        self.selected_op_type_combo = QComboBox()
        self.selected_op_type_combo.addItems(get_all_op_display_names())
        self.selected_op_type_combo.currentIndexChanged.connect(self._on_selected_op_type_changed)
        self.params_layout.addWidget(self.selected_op_type_combo)

        # Stacked widget for operation-specific parameters
        self.params_stacked_widget = QStackedWidget()
        self.params_layout.addWidget(self.params_stacked_widget)
        
        # Dynamically build the UI based on the registry
        self._build_dynamic_ui()
        self._connect_signals_to_dynamic_ui() # Connects signals after all widgets are built
        
        self.params_layout.addStretch()
        
        self._update_operation_list()
        self._update_selected_operation_details() # Selects the first operation if any, or hides params

    def _build_dynamic_ui(self):
        """
        Builds all parameter widgets for all operations from the registry.
        This method is now more robust in handling nested LUT parameters.
        """
        self.op_widgets: Dict[str, QWidget] = {} # Stores widgets for main operations
        self.lut_sub_widgets: Dict[str, QWidget] = {} # Stores widgets for generated LUT sub-types

        for op_type, op_data in OPERATIONS_REGISTRY.items():
            op_params_widget = QWidget()
            op_params_layout = QVBoxLayout(op_params_widget)
            op_params_layout.setContentsMargins(0, 0, 0, 0)
            self.op_widgets[op_type] = op_params_widget

            if op_type == "apply_lut":
                # LUT Source (Generated/File)
                self.lut_source_combo = QComboBox()
                self.lut_source_combo.addItems([
                    PARAM_DEFINITIONS["lut_source"]["choices"][0],
                    PARAM_DEFINITIONS["lut_source"]["choices"][1]
                ])
                op_params_layout.addWidget(self.lut_source_combo)
                self.add_param_widget_ref("lut_source", self.lut_source_combo) # Store reference

                # Stacked widget for LUT source controls (Generated vs File)
                self.lut_gen_params_stacked_widget = QStackedWidget()
                op_params_layout.addWidget(self.lut_gen_params_stacked_widget)
                
                # --- Generated LUTs Panel ---
                self.generated_lut_params_widget = QWidget()
                self.generated_lut_params_layout = QVBoxLayout(self.generated_lut_params_widget)
                self.generated_lut_params_layout.setContentsMargins(0,0,0,0)
                self.lut_gen_params_stacked_widget.addWidget(self.generated_lut_params_widget)
                
                # Generation type combobox
                self.lut_generation_type_combo = QComboBox()
                self.lut_generation_type_combo.addItems(PARAM_DEFINITIONS["lut_generation_type"]["choices"])
                self.generated_lut_params_layout.addWidget(self.lut_generation_type_combo)
                self.add_param_widget_ref("lut_generation_type", self.lut_generation_type_combo) # Store reference
                
                # Stacked widget for LUT type parameters (e.g., gamma, s-curve)
                self.gen_lut_algo_params_stacked_widget = QStackedWidget()
                self.generated_lut_params_layout.addWidget(self.gen_lut_algo_params_stacked_widget)
                
                # Dynamically create widgets for each generated LUT sub-type
                # Iterate through 'types' inside 'generated' in OPERATIONS_REGISTRY
                generated_lut_types = OPERATIONS_REGISTRY["apply_lut"]["sub_params"]["generated"]["types"]
                for lut_gen_subtype, param_names in generated_lut_types.items():
                    sub_type_widget_container = self._create_param_widgets(param_names)
                    self.lut_sub_widgets[lut_gen_subtype] = sub_type_widget_container # Store for lookup
                    self.gen_lut_algo_params_stacked_widget.addWidget(sub_type_widget_container)

                # --- File-based LUTs Panel ---
                self.file_lut_params_widget = self._create_param_widgets(OPERATIONS_REGISTRY["apply_lut"]["sub_params"]["file"]["params"])
                self.lut_gen_params_stacked_widget.addWidget(self.file_lut_params_widget)
                
                # Add file dialog buttons to the file-based LUTs panel's layout
                load_btn = QPushButton("Load LUT File")
                load_btn.clicked.connect(self._load_lut_from_file_for_op)
                save_btn = QPushButton("Save Current LUT")
                save_btn.clicked.connect(self._save_lut_to_file_from_op)
                lut_btn_layout = QHBoxLayout()
                lut_btn_layout.addWidget(load_btn)
                lut_btn_layout.addWidget(save_btn)
                # This assumes file_lut_params_widget already has a layout (from _create_param_widgets)
                self.file_lut_params_widget.layout().addLayout(lut_btn_layout)
                
            else: # For non-LUT operations
                param_names = op_data["params"]
                param_widgets_container = self._create_param_widgets(param_names)
                op_params_layout.addWidget(param_widgets_container)
            
            self.params_stacked_widget.addWidget(op_params_widget)

    def add_param_widget_ref(self, param_name: str, widget: QWidget):
        """Helper to add widget references to the correct dictionary."""
        self._param_widgets[param_name] = widget
        if isinstance(widget, QSlider):
            self._slider_widgets[param_name] = widget


    def _create_param_widgets(self, param_names: List[str]) -> QWidget:
        """Helper to create widgets for a list of parameter names, storing references."""
        container = QWidget()
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(0, 0, 0, 0) # Remove extra margins inside containers
        
        for param_name in param_names:
            param_def = PARAM_DEFINITIONS.get(param_name)
            if not param_def:
                print(f"Warning: Parameter definition not found for '{param_name}'. Skipping widget creation.")
                continue

            h_layout = QHBoxLayout()
            label = QLabel(param_def["label"] + ":")
            h_layout.addWidget(label)
            
            widget: QWidget
            if "choices" in param_def:
                widget = QComboBox()
                widget.addItems(param_def["choices"])
            else: # Default to QLineEdit
                widget = QLineEdit()
                
            h_layout.addWidget(widget)
            self.add_param_widget_ref(param_name, widget) # Store reference in main param_widgets dict
            
            container_layout.addLayout(h_layout) # Add the label and input widget row

            if "slider" in param_def:
                slider_def = param_def["slider"]
                slider = QSlider(Qt.Horizontal)
                slider.setMinimum(slider_def["min"])
                slider.setMaximum(slider_def["max"])
                slider.setSingleStep(1)
                
                # Store slider separately with its actual param_name, not a derived one
                self.add_param_widget_ref(f"{param_name}_slider", slider) # Store reference for slider
                
                container_layout.addWidget(slider) # Add slider below its text input

        container_layout.addStretch() # Push content to top
        return container

    def _connect_signals_to_dynamic_ui(self):
        """Connects signals for all dynamically created widgets."""
        for param_name, widget in self._param_widgets.items():
            # Check if it's a slider, as sliders are stored with a "_slider" suffix
            if param_name.endswith("_slider"):
                param_name_without_slider = param_name.replace("_slider", "")
                param_def = PARAM_DEFINITIONS.get(param_name_without_slider)
                if param_def and "slider" in param_def:
                    scale_factor = param_def["slider"]["scale_factor"]
                    # Connect slider to a generic handler that updates its associated QLineEdit
                    if isinstance(widget, QSlider):
                        widget.valueChanged.connect(
                            lambda value, name=param_name_without_slider, scale=scale_factor: self._on_slider_value_changed(name, value, scale)
                        )
            else: # It's a QLineEdit or QComboBox
                param_def = PARAM_DEFINITIONS.get(param_name)
                if not param_def: continue # Should not happen if build_dynamic_ui is correct

                if isinstance(widget, QLineEdit):
                    widget.textChanged.connect(
                        lambda text, name=param_name: self._update_param_in_config(name, text)
                    )
                elif isinstance(widget, QComboBox):
                    # lut_source and lut_generation_type need to trigger a UI re-layout
                    # All other combo boxes just update their value
                    if param_name in ["lut_source", "lut_generation_type"]:
                        widget.currentIndexChanged.connect(
                            lambda index, name=param_name: self._update_param_in_config(name, widget.currentText())
                        )
                    else: # Generic combo box for other choices like resample_mode
                        widget.currentTextChanged.connect(
                            lambda text, name=param_name: self._update_param_in_config(name, text)
                        )
    
    def _on_slider_value_changed(self, param_name: str, value: int, scale_factor: float):
        """
        Handles slider value changes and updates the corresponding line edit and config.
        param_name here is the *base* parameter name (e.g., "gamma_value").
        """
        text_edit_widget = self._param_widgets.get(param_name) # Get the QLineEdit
        if isinstance(text_edit_widget, QLineEdit):
            new_value = value / scale_factor
            # Block signals temporarily to prevent infinite loop
            text_edit_widget.blockSignals(True)
            text_edit_widget.setText(str(new_value))
            text_edit_widget.blockSignals(False)
            
            # Now explicitly update the config based on the new text
            self._update_param_in_config(param_name, str(new_value))


    def _update_operation_list(self):
        """Refreshes the list widget from the config pipeline."""
        self.ops_list_widget.blockSignals(True)
        self.ops_list_widget.clear()
        for i, op in enumerate(self.config.xy_blend_pipeline):
            display_name = get_op_display_name(op.type)
            self.ops_list_widget.addItem(f"{i+1}: {display_name}")
        self.ops_list_widget.blockSignals(False)
        # Select the first item if the list is not empty, otherwise ensure no selection
        if self.ops_list_widget.count() > 0 and self.ops_list_widget.currentRow() == -1:
            self.ops_list_widget.setCurrentRow(0)


    def _update_selected_operation_details(self, current_row: int = -1):
        """Updates the parameter UI based on the selected operation."""
        # Save current state before switching
        self.save_current_operation_params()
        
        current_row = self.ops_list_widget.currentRow() if current_row == -1 else current_row
        
        self.params_group_widget.setVisible(current_row >= 0)
        if current_row < 0 or current_row >= len(self.config.xy_blend_pipeline):
            self.operation_changed.emit()
            return

        selected_op = self.config.xy_blend_pipeline[current_row]
        
        self._block_all_param_signals(True) # Block signals before populating to avoid unwanted updates
        
        # Update the main op type dropdown
        op_display_name = get_op_display_name(selected_op.type)
        # Find index by text. `blockSignals` helps prevent triggering _on_selected_op_type_changed immediately.
        self.selected_op_type_combo.setCurrentText(op_display_name) 
        
        # Show the correct parameter stack for the main operation type
        op_widget = self.op_widgets.get(selected_op.type)
        if op_widget:
            self.params_stacked_widget.setCurrentWidget(op_widget)

        self._populate_params_widgets(selected_op)
        
        self._block_all_param_signals(False) # Unblock signals after population
        
        self._plot_current_lut_preview(selected_op.lut_params) # Ensure LUT preview updates
        self.operation_changed.emit()


    def _populate_params_widgets(self, op: Any):
        """Generic function to populate all widgets based on the selected op object."""
        op_data = OPERATIONS_REGISTRY.get(op.type, {})
        param_names = op_data.get("params", [])

        # Populate regular parameters
        for param_name in param_names:
            widget = self._param_widgets.get(param_name)
            if widget:
                param_def = PARAM_DEFINITIONS.get(param_name)
                # Correctly get the attribute, handling 'lut_' prefix for LutParameters
                attr_name = param_name.replace("lut_", "") if param_name.startswith("lut_") else param_name
                target_obj = op.lut_params if param_name.startswith("lut_") else op
                current_value = getattr(target_obj, attr_name, param_def.get("default"))
                self._set_widget_value(widget, current_value, param_def, param_name) # Pass param_name to _set_widget_value

        # Handle special case for apply_lut
        if op.type == "apply_lut":
            lut_params = op.lut_params
            
            # Update Lut source combo
            self.lut_source_combo.setCurrentText(lut_params.lut_source.capitalize())
            is_generated = lut_params.lut_source.lower() == "generated"
            self.lut_gen_params_stacked_widget.setCurrentWidget(self.generated_lut_params_widget if is_generated else self.file_lut_params_widget)
            
            # If generated, populate its sub-controls
            if is_generated:
                self.lut_generation_type_combo.setCurrentText(lut_params.lut_generation_type.capitalize())
                
                # Set the correct LUT algorithm stack
                sub_widget_container = self.lut_sub_widgets.get(lut_params.lut_generation_type)
                if sub_widget_container:
                    self.gen_lut_algo_params_stacked_widget.setCurrentWidget(sub_widget_container)

                # Populate algorithm parameters for the selected generated type
                # Retrieve the specific parameters for the selected LUT generation type
                generated_lut_types = OPERATIONS_REGISTRY["apply_lut"]["sub_params"]["generated"]["types"]
                sub_param_names = generated_lut_types.get(lut_params.lut_generation_type, [])
                
                for param_name in sub_param_names:
                    widget = self._param_widgets.get(param_name)
                    if widget:
                        param_def = PARAM_DEFINITIONS.get(param_name)
                        attr_name = param_name.replace("lut_", "") # Remove 'lut_' prefix for getattr
                        current_value = getattr(lut_params, attr_name, param_def.get("default"))
                        self._set_widget_value(widget, current_value, param_def, param_name)
            else: # If file, populate file path
                widget = self._param_widgets.get("lut_filepath_edit")
                if widget and isinstance(widget, QLineEdit):
                    widget.setText(lut_params.fixed_lut_path)
                    # No slider for file path
        
        # Plot LUT preview after all params are populated
        self._plot_current_lut_preview(op.lut_params)


    def _set_widget_value(self, widget: QWidget, value: Any, param_def: Dict[str, Any], param_name: str):
        """
        Helper to set a widget's value based on its type.
        Now correctly handles slider updates in sync with line edits.
        """
        if isinstance(widget, QLineEdit):
            # Block signals to prevent _update_param_in_config from being called
            # just because we're programmatically setting the text.
            widget.blockSignals(True)
            if value is None:
                widget.setText("")
            elif isinstance(value, (int, float, str)):
                widget.setText(str(value))
            widget.blockSignals(False)

            # Now update the associated slider if it exists
            if "slider" in param_def:
                slider = self._slider_widgets.get(f"{param_name}_slider") # Correctly get slider reference
                if slider and value is not None:
                    scale_factor = param_def["slider"]["scale_factor"]
                    slider_value = int(float(value) * scale_factor)
                    slider.blockSignals(True) # Block slider signals too
                    slider.setValue(slider_value)
                    slider.blockSignals(False)

        elif isinstance(widget, QComboBox):
            widget.blockSignals(True)
            if value is not None:
                # Find index by text, case-insensitively if needed, or by exact match
                index = widget.findText(str(value).capitalize(), Qt.MatchFlag.MatchExactly)
                if index == -1: # Try case-insensitive
                    index = widget.findText(str(value), Qt.MatchFlag.MatchExactly)
                if index != -1:
                    widget.setCurrentIndex(index)
                else:
                    print(f"Warning: Could not set QComboBox '{param_name}' to value '{value}'. Value not in choices.")
            widget.blockSignals(False)
    
    def _block_all_param_signals(self, block: bool):
        """Blocks/unblocks signals for all parameter QLineEdits, QComboBoxes, and QSliders."""
        for widget in self._param_widgets.values():
            widget.blockSignals(block)
        for slider_widget in self._slider_widgets.values(): # Ensure sliders are also blocked
            slider_widget.blockSignals(block)


    def _on_selected_op_type_changed(self, index: int):
        """Handles a change in the operation type dropdown."""
        current_row = self.ops_list_widget.currentRow()
        if current_row < 0 or current_row >= len(self.config.xy_blend_pipeline):
            return
        
        # Map back from display name to op type string
        op_display_text = self.selected_op_type_combo.currentText()
        # Find the actual op_type (key) from OPERATIONS_REGISTRY based on display name
        op_type = "none"
        for k, v in OPERATIONS_REGISTRY.items():
            if v.get("display_name") == op_display_text:
                op_type = k
                break

        # Only proceed if the type actually changed to avoid unnecessary re-initialization
        if self.config.xy_blend_pipeline[current_row].type == op_type:
            return

        # Replace the current operation in the pipeline with a new instance of the selected type
        # This effectively resets parameters to defaults for the new type
        new_op_instance = XYBlendOperation(type=op_type)
        self.config.xy_blend_pipeline[current_row] = new_op_instance
        
        self._block_all_param_signals(True) # Block signals before populating new widgets
        
        # Update the UI to reflect the new operation's default parameters
        self._populate_params_widgets(self.config.xy_blend_pipeline[current_row])
        
        # Show the correct parameter stack for the new operation type
        op_widget = self.op_widgets.get(op_type)
        if op_widget:
            self.params_stacked_widget.setCurrentWidget(op_widget)

        self._block_all_param_signals(False) # Unblock signals

        self._update_operation_list() # Refresh list text to show new type
        self.ops_list_widget.setCurrentRow(current_row) # Re-select the item
        self.operation_changed.emit()


    def _update_param_in_config(self, param_name: str, text: str):
        """
        Generic function to update any parameter in the config.
        Handles type conversion and validation.
        """
        current_row = self.ops_list_widget.currentRow()
        if current_row < 0: return

        selected_op = self.config.xy_blend_pipeline[current_row]
        param_def = PARAM_DEFINITIONS.get(param_name)
        if not param_def: return

        # Determine the target object (op or op.lut_params) and attribute name
        attr_name = param_name.replace("lut_", "") # Remove 'lut_' prefix for dataclass attribute
        target_obj = selected_op.lut_params if param_name.startswith("lut_") else selected_op

        value_to_set = None
        try:
            if not text and param_def.get("allow_none_if_zero"):
                value_to_set = None
            elif not text: # If text is empty and None is not allowed, use default
                value_to_set = param_def.get("default")
            else:
                if "choices" in param_def:
                    value_to_set = text.lower() # Store choice as lowercase string
                else:
                    value_to_set = param_def["type"](text) # Convert to target type (int, float)
            
            # Apply error styling and do not update config if conversion fails.
            # Clear error styling on success.
            widget = self._param_widgets.get(param_name)
            if widget and isinstance(widget, QLineEdit):
                widget.setStyleSheet("")
            
            # Set the attribute on the target object
            setattr(target_obj, attr_name, value_to_set)

        except (ValueError, TypeError) as e:
            # Apply error styling
            widget = self._param_widgets.get(param_name)
            if widget and isinstance(widget, QLineEdit):
                widget.setStyleSheet("border: 1px solid red;")
            print(f"Validation Error for param '{param_name}' with value '{text}': {e}")
            return # Do not update config with invalid value
        
        # Re-run __post_init__ to apply any internal validation/correction (e.g., ksize odd, clipping)
        target_obj.__post_init__()
        
        # Update UI if the value was corrected by __post_init__
        corrected_value = getattr(target_obj, attr_name)
        if corrected_value != value_to_set:
            widget = self._param_widgets.get(param_name)
            if widget and isinstance(widget, QLineEdit):
                widget.blockSignals(True)
                widget.setText(str(corrected_value) if corrected_value is not None else "")
                widget.blockSignals(False)
            # Also update the slider if it exists and value was corrected
            slider = self._slider_widgets.get(f"{param_name}_slider")
            if slider and "slider" in param_def and corrected_value is not None:
                scale_factor = param_def["slider"]["scale_factor"]
                slider_value = int(float(corrected_value) * scale_factor)
                slider.blockSignals(True)
                slider.setValue(slider_value)
                slider.blockSignals(False)

        # Special handling for LUT type changes - needs to re-stack panels
        if param_name == "lut_source":
            is_generated = text.lower() == "generated"
            self.lut_gen_params_stacked_widget.setCurrentWidget(self.generated_lut_params_widget if is_generated else self.file_lut_params_widget)
            # Re-populate sub-params in case source changes and needs default for new type
            if is_generated: # Only if changing TO generated, update its inner stack
                 self.lut_generation_type_combo.setCurrentText(target_obj.lut_generation_type.capitalize())
                 sub_widget = self.lut_sub_widgets.get(target_obj.lut_generation_type)
                 if sub_widget:
                    self.gen_lut_algo_params_stacked_widget.setCurrentWidget(sub_widget)
        elif param_name == "lut_generation_type":
            sub_widget = self.lut_sub_widgets.get(text.lower())
            if sub_widget:
                self.gen_lut_algo_params_stacked_widget.setCurrentWidget(sub_widget)

        self._plot_current_lut_preview(selected_op.lut_params)
        self.operation_changed.emit()

    def _plot_current_lut_preview(self, lut_params):
        """
        Generates/loads the LUT using the registry and plots it.
        Uses a dictionary lookup for generator functions and passes appropriate parameters.
        """
        generated_lut = None
        try:
            if lut_params.lut_source == "generated":
                generator_func = LUT_GENERATOR_FUNCTIONS.get(lut_params.lut_generation_type)
                if generator_func:
                    # Collect parameters for the specific LUT generation type
                    if lut_params.lut_generation_type == "linear":
                        generated_lut = generator_func(lut_params.linear_min_input, lut_params.linear_max_output)
                    elif lut_params.lut_generation_type == "gamma":
                        generated_lut = generator_func(lut_params.gamma_value)
                    elif lut_params.lut_generation_type == "s_curve":
                        generated_lut = generator_func(lut_params.s_curve_contrast)
                    elif lut_params.lut_generation_type == "log":
                        generated_lut = generator_func(lut_params.log_param)
                    elif lut_params.lut_generation_type == "exp":
                        generated_lut = generator_func(lut_params.exp_param)
                    elif lut_params.lut_generation_type == "sqrt":
                        generated_lut = generator_func(lut_params.sqrt_param)
                    elif lut_params.lut_generation_type == "rodbard":
                        generated_lut = generator_func(lut_params.rodbard_param)
                    # Add more elif for other generated LUT types if they take different params
                    else:
                        print(f"Warning: Unknown LUT generation type '{lut_params.lut_generation_type}' for preview. Using default identity LUT.")
                        generated_lut = lut_manager.get_default_z_lut()
                else:
                    print(f"Warning: No generator function found for '{lut_params.lut_generation_type}'. Using default identity LUT.")
                    generated_lut = lut_manager.get_default_z_lut()
            elif lut_params.lut_source == "file":
                if lut_params.fixed_lut_path and os.path.exists(lut_params.fixed_lut_path):
                    generated_lut = lut_manager.load_lut(lut_params.fixed_lut_path)
                else:
                    print(f"Warning: LUT file not found at '{lut_params.fixed_lut_path}'. Using default identity LUT for preview.")
                    generated_lut = lut_manager.get_default_z_lut()
            else:
                print(f"Warning: Invalid LUT source '{lut_params.lut_source}'. Using default identity LUT for preview.")
                generated_lut = lut_manager.get_default_z_lut()
        except Exception as e:
            print(f"Error generating/loading LUT for plot preview: {e}. Using default identity LUT.")
            generated_lut = lut_manager.get_default_z_lut()

        # Ensure a valid LUT is always plotted
        if generated_lut is None:
            generated_lut = lut_manager.get_default_z_lut()

        self.axes.clear()
        self.axes.plot(np.arange(256), generated_lut, 'b-')
        self.axes.set_title("LUT Curve Preview")
        self.axes.set_xlabel("Input Value (0-255)")
        self.axes.set_ylabel("Output Value (0-255)")
        self.axes.set_xlim(0, 255)
        self.axes.set_ylim(0, 255)
        self.axes.grid(True)
        self.canvas.draw()
    
    # Other methods like _add_operation, _remove_operation, etc., remain largely the same.
    # The `save_current_operation_params` method is also refactored to be generic.
    
    def save_current_operation_params(self):
        """
        Reads values from the UI controls for the active operation and saves them to the config.
        Now uses the registry to find which parameters to save.
        """
        current_row = self.ops_list_widget.currentRow()
        if current_row < 0: return

        op = self.config.xy_blend_pipeline[current_row]
        op_type = op.type
        op_data = OPERATIONS_REGISTRY.get(op_type, {})
        
        all_param_names = op_data.get("params", [])

        # If it's apply_lut, need to get parameters for the *specific* lut_source and lut_generation_type
        if op_type == "apply_lut":
            # First, save lut_source and lut_generation_type from their comboboxes
            lut_source_widget = self._param_widgets.get("lut_source")
            if isinstance(lut_source_widget, QComboBox):
                lut_source_text = lut_source_widget.currentText().lower()
                op.lut_params.lut_source = lut_source_text
            
            if lut_source_text == "generated":
                lut_gen_type_widget = self._param_widgets.get("lut_generation_type")
                if isinstance(lut_gen_type_widget, QComboBox):
                    lut_gen_type_text = lut_gen_type_widget.currentText().lower()
                    op.lut_params.lut_generation_type = lut_gen_type_text
                    
                # Add generated LUT sub-parameters to the list of params to save
                generated_lut_types = op_data.get("sub_params", {}).get("generated", {}).get("types", {})
                sub_params_for_type = generated_lut_types.get(lut_gen_type_text, [])
                all_param_names.extend(sub_params_for_type)
            else: # lut_source is "file"
                # Add file-based LUT parameters to the list of params to save
                file_params = op_data.get("sub_params", {}).get("file", {}).get("params", [])
                all_param_names.extend(file_params)

        for param_name in all_param_names:
            widget = self._param_widgets.get(param_name)
            if not widget: continue # Skip if widget not found (e.g., param not defined in UI)

            param_def = PARAM_DEFINITIONS.get(param_name)
            if not param_def: continue # Should not happen if params are correctly defined in registry

            value_to_set = None
            if isinstance(widget, QLineEdit):
                text = widget.text()
                if not text and param_def.get("allow_none_if_zero"):
                    value_to_set = None
                elif not text: # If text is empty and None is not allowed, use default
                    value_to_set = param_def.get("default")
                else:
                    try:
                        value_to_set = param_def["type"](text)
                    except (ValueError, TypeError):
                        print(f"Warning: Could not convert text '{text}' for parameter '{param_name}'. Skipping save.")
                        continue # Skip invalid values, do not update config
            elif isinstance(widget, QComboBox):
                value_to_set = widget.currentText().lower()
            
            # Determine the target object and attribute name for setting the value
            attr_name = param_name.replace("lut_", "")
            target_obj = op.lut_params if param_name.startswith("lut_") else op
            
            # Use setattr for dynamic assignment
            setattr(target_obj, attr_name, value_to_set)

        # Ensure __post_init__ is called for the operation and its lut_params after saving
        op.__post_init__()
        if op.type == "apply_lut":
            op.lut_params.__post_init__()

    # Remaining methods are unchanged: _add_operation, _remove_operation, etc.
    # ...
    def _add_operation(self):
        current_op_type_display = self.selected_op_type_combo.currentText()
        # Find the actual op_type (key) from OPERATIONS_REGISTRY based on display name
        current_op_type = "none" # Default in case display name is not found
        for k, v in OPERATIONS_REGISTRY.items():
            if v.get("display_name") == current_op_type_display:
                current_op_type = k
                break

        new_op = XYBlendOperation(type=current_op_type)
        self.config.xy_blend_pipeline.append(new_op)
        self._update_operation_list()
        self.ops_list_widget.setCurrentRow(len(self.config.xy_blend_pipeline) - 1)
        self.operation_changed.emit() # Emit signal after adding/selecting new op

    def _remove_operation(self):
        current_row = self.ops_list_widget.currentRow()
        if current_row >= 0 and current_row < len(self.config.xy_blend_pipeline):
            reply = QMessageBox.question(self, "Remove Operation",
                                         f"Are you sure you want to remove operation {current_row+1}?",
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                del self.config.xy_blend_pipeline[current_row]
                self._update_operation_list()
                if self.ops_list_widget.count() > 0:
                    new_row = min(current_row, self.ops_list_widget.count() - 1)
                    self.ops_list_widget.setCurrentRow(new_row)
                else:
                    self._update_selected_operation_details() # This will hide the params group
                self.operation_changed.emit()

    def _move_operation_up(self):
        current_row = self.ops_list_widget.currentRow()
        if current_row > 0:
            self.config.xy_blend_pipeline[current_row], self.config.xy_blend_pipeline[current_row - 1] = \
                self.config.xy_blend_pipeline[current_row - 1], self.config.xy_blend_pipeline[current_row]
            self._update_operation_list()
            self.ops_list_widget.setCurrentRow(current_row - 1)
            self.operation_changed.emit()

    def _move_operation_down(self):
        current_row = self.ops_list_widget.currentRow()
        if current_row < len(self.config.xy_blend_pipeline) - 1:
            self.config.xy_blend_pipeline[current_row], self.config.xy_blend_pipeline[current_row + 1] = \
                self.config.xy_blend_pipeline[current_row + 1], self.config.xy_blend_pipeline[current_row]
            self._update_operation_list()
            self.ops_list_widget.setCurrentRow(current_row + 1)
            self.operation_changed.emit()

    def _reorder_operations_in_config(self, parent, start, end, destination, row):
        # This signal is tricky with drag/drop. The QListWidget handles the visual move.
        # We need to re-sync the underlying data.
        # The 'row' parameter in rowsMoved is the *new* start index.
        # The 'destination' parameter is ignored for internal moves; we need to infer based on original and new index.

        # Ensure _update_selected_operation_details doesn't save potentially half-updated state during drag
        # (It should be called *after* the reorder is complete and a selection is made)
        
        # Temporarily block selection signal to avoid re-triggering details update
        self.ops_list_widget.blockSignals(True)
        
        moved_op = self.config.xy_blend_pipeline.pop(start)
        # Adjust target index if moving downwards
        if row > start:
            row -= 1 # Adjust for item being removed from earlier position
        
        self.config.xy_blend_pipeline.insert(row, moved_op)
        
        # Re-populate list to ensure order is visually correct
        self._update_operation_list() 
        self.ops_list_widget.setCurrentRow(row) # Select the moved item in its new position
        self.ops_list_widget.blockSignals(False) # Unblock signals
        self.operation_changed.emit() # Emit after reorder and selection is stable

    def _load_lut_from_file_for_op(self):
        current_row = self.ops_list_widget.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, "No Operation Selected", "Please select an 'Apply LUT' operation first.")
            return
        selected_op = self.config.xy_blend_pipeline[current_row]
        if selected_op.type != "apply_lut":
            QMessageBox.warning(self, "Invalid Operation Type", "Please select an 'Apply LUT' operation to load a LUT file.")
            return
        initial_path = selected_op.lut_params.fixed_lut_path or ""
        filepath, _ = QFileDialog.getOpenFileName(self, "Load LUT File", initial_path, "JSON Files (*.json);;All Files (*)")
        if filepath:
            try:
                # Validate LUT file can be loaded
                temp_lut = lut_manager.load_lut(filepath) 
                
                self._block_all_param_signals(True)
                selected_op.lut_params.fixed_lut_path = filepath
                selected_op.lut_params.lut_source = "file" # Automatically set source to file
                selected_op.lut_params.__post_init__() # Run post_init to ensure validation
                
                # Update UI widgets
                if "lut_filepath_edit" in self._param_widgets:
                    self._param_widgets["lut_filepath_edit"].setText(filepath)
                if "lut_source" in self._param_widgets:
                    self._param_widgets["lut_source"].setCurrentText("File")
                
                # Ensure the correct stacked widget is shown
                self.lut_gen_params_stacked_widget.setCurrentWidget(self.file_lut_params_widget)

                self._block_all_param_signals(False)
                self._plot_current_lut_preview(selected_op.lut_params)
                QMessageBox.information(self, "Load Success", f"LUT file set for operation: '{os.path.basename(filepath)}'.")
                self.operation_changed.emit() # Signal that config might have changed
            except Exception as e:
                QMessageBox.critical(self, "Load Error", f"Failed to load/validate LUT file: {e}")
                # Clear invalid path and plot default if loading failed
                if "lut_filepath_edit" in self._param_widgets:
                    self._param_widgets["lut_filepath_edit"].setText("")
                self._plot_current_lut_preview(selected_op.lut_params) # Plot default if error

    def _save_lut_to_file_from_op(self):
        current_row = self.ops_list_widget.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, "No Operation Selected", "Please select an 'Apply LUT' operation first.")
            return
        selected_op = self.config.xy_blend_pipeline[current_row]
        if selected_op.type != "apply_lut":
            QMessageBox.warning(self, "Invalid Operation Type", "Please select an 'Apply LUT' operation to save its LUT.")
            return
        
        generated_lut_array = None
        try:
            # Re-generate/load the LUT to ensure it's the current one based on UI parameters
            lut_params = selected_op.lut_params # Get current parameters
            if lut_params.lut_source == "generated":
                generator_func = LUT_GENERATOR_FUNCTIONS.get(lut_params.lut_generation_type)
                if generator_func:
                    if lut_params.lut_generation_type == "linear":
                        generated_lut_array = generator_func(lut_params.linear_min_input, lut_params.linear_max_output)
                    elif lut_params.lut_generation_type == "s_curve":
                        generated_lut_array = generator_func(lut_params.s_curve_contrast)
                    elif lut_params.lut_generation_type == "gamma":
                        generated_lut_array = generator_func(lut_params.gamma_value)
                    elif lut_params.lut_generation_type == "log":
                        generated_lut_array = generator_func(lut_params.log_param)
                    elif lut_params.lut_generation_type == "exp":
                        generated_lut_array = generator_func(lut_params.exp_param)
                    elif lut_params.lut_generation_type == "sqrt":
                        generated_lut_array = generator_func(lut_params.sqrt_param)
                    elif lut_params.lut_generation_type == "rodbard":
                        generated_lut_array = generator_func(lut_params.rodbard_param)
                    else:
                         raise ValueError(f"Unknown generated LUT type for saving: {lut_params.lut_generation_type}")
                else:
                    raise ValueError(f"No generator function found for type: {lut_params.lut_generation_type}")
            elif lut_params.lut_source == "file":
                if lut_params.fixed_lut_path and os.path.exists(lut_params.fixed_lut_path):
                    generated_lut_array = lut_manager.load_lut(lut_params.fixed_lut_path)
                else:
                    QMessageBox.warning(self, "LUT File Not Found", "No valid LUT file specified to save, or file does not exist. Cannot save.")
                    return
            else:
                raise ValueError(f"Unknown LUT source: {lut_params.lut_source}")
            
            if generated_lut_array is None:
                raise ValueError("Could not generate or load LUT for saving.")

        except Exception as e:
            QMessageBox.critical(self, "LUT Save Error", f"Failed to prepare LUT for saving: {e}")
            return
        
        default_filename = os.path.basename(selected_op.lut_params.fixed_lut_path) if selected_op.lut_params.fixed_lut_path else "custom_lut_op.json"
        filepath, _ = QFileDialog.getSaveFileName(self, "Save LUT for Operation", default_filename, "JSON Files (*.json);;All Files (*)")
        if filepath:
            try:
                lut_manager.save_lut(filepath, generated_lut_array)
                QMessageBox.information(self, "Save Success", f"LUT saved to '{filepath}'.")
            except Exception as e:
                QMessageBox.critical(self, "Save Error", f"Failed to save LUT: {e}")

    def get_config(self) -> dict:
        """Returns the current pipeline configuration as a dictionary."""
        self.save_current_operation_params() # Ensure current params are saved before returning config
        return {"xy_blend_pipeline": [op.to_dict() for op in self.config.xy_blend_pipeline]}

    def apply_settings(self, cfg: Config):
        """Applies configuration settings to the UI of this tab."""
        self._block_all_param_signals(True)
        self.config = cfg # Update the internal config reference
        self._update_operation_list()
        self._update_selected_operation_details()
        self._block_all_param_signals(False)