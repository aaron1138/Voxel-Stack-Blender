# xy_blend_processor.py (Refactored & Fixed for Circular Import)

import cv2
import numpy as np
import os
from typing import List, Any, Optional, Dict, Callable

# ONLY import the dataclass definitions that are used as type hints or objects here.
# These are simple data structures, so it's safe to import them.
from operations_registry import XYBlendOperation, LutParameters 

# Import lut_manager as it provides the core LUT functions
import lut_manager

# --- Helper Function (if needed locally) ---
def _ensure_odd_ksize(ksize: int) -> int:
    """Ensures a kernel size is an odd integer, adjusting if necessary."""
    if ksize % 2 == 0:
        return ksize + 1 if ksize > 0 else 1
    return ksize

# --- Individual Processing Functions ---
# These functions now take the operation object directly and access its parameters.
# They are independent of the global OPERATIONS_REGISTRY or LUT_GENERATOR_FUNCTIONS.

def apply_gaussian_blur(image: np.ndarray, op: XYBlendOperation) -> np.ndarray:
    """
    Applies Gaussian blur to an 8-bit image (grayscale or color).
    Uses configurable separable X and Y kernel sizes and sigmas.
    """
    ksize_x = op.gaussian_ksize_x
    ksize_y = op.gaussian_ksize_y
    sigma_x = op.gaussian_sigma_x
    sigma_y = op.gaussian_sigma_y
    
    # Ensure ksize_x and ksize_y are odd as required by OpenCV
    # The __post_init__ in XYBlendOperation should handle this, but defensive check won't hurt
    ksize_x = _ensure_odd_ksize(ksize_x)
    ksize_y = _ensure_odd_ksize(ksize_y)

    return cv2.GaussianBlur(image, (ksize_x, ksize_y), sigmaX=sigma_x, sigmaY=sigma_y)

def apply_bilateral_filter(image: np.ndarray, op: XYBlendOperation) -> np.ndarray:
    """
    Applies a bilateral filter to an 8-bit image (grayscale or color).
    """
    d = op.bilateral_d
    sigma_color = op.bilateral_sigma_color
    sigma_space = op.bilateral_sigma_space
    
    # Bilateral filter for color images usually needs to be applied per channel or converted to appropriate color space
    if len(image.shape) == 3:
        # For simplicity, applying to BGR channels. More advanced might convert to LAB.
        filtered_channels = [cv2.bilateralFilter(image[:,:,i], d, sigma_color, sigma_space) for i in range(image.shape[2])]
        return cv2.merge(filtered_channels)
    else:
        return cv2.bilateralFilter(image, d, sigma_color, sigma_space)

def apply_median_blur(image: np.ndarray, op: XYBlendOperation) -> np.ndarray:
    """
    Applies a median blur to an 8-bit image (grayscale or color).
    """
    ksize = op.median_ksize
    ksize = _ensure_odd_ksize(ksize) # Ensure ksize is odd

    if ksize <= 1: # Median filter with ksize 1 does nothing
        return image
    
    # OpenCV's medianBlur can handle multi-channel images directly if dtype is uint8
    return cv2.medianBlur(image, ksize)

def apply_unsharp_mask(image: np.ndarray, op: XYBlendOperation) -> np.ndarray:
    """
    Applies unsharp masking to an 8-bit image for sharpening.
    """
    amount = op.unsharp_amount
    threshold = op.unsharp_threshold
    blur_ksize = op.unsharp_blur_ksize
    blur_sigma = op.unsharp_blur_sigma

    # Ensure blur_ksize is odd
    blur_ksize = _ensure_odd_ksize(blur_ksize)

    blurred_image = cv2.GaussianBlur(image, (blur_ksize, blur_ksize), sigmaX=blur_sigma, sigmaY=blur_sigma)
    
    # Convert to float for calculation to prevent clipping during intermediate steps
    image_float = image.astype(np.float32)
    blurred_image_float = blurred_image.astype(np.float32)

    # Calculate detail layer (original - blurred)
    detail_layer = image_float - blurred_image_float

    if threshold > 0:
        # Create a mask for areas where the absolute detail is above threshold
        # This prevents amplifying noise in flat regions
        abs_detail = np.abs(detail_layer)
        mask = (abs_detail > threshold).astype(np.float32)
        
        # Apply mask to detail layer
        detail_layer = detail_layer * mask
    
    # sharpened_image = original + amount * detail_layer
    sharpened_image = image_float + amount * detail_layer
    
    # Clip and convert back to uint8
    return np.clip(sharpened_image, 0, 255).astype(np.uint8)


def apply_resize(image: np.ndarray, op: XYBlendOperation) -> np.ndarray:
    """
    Resizes an image. Handles proportional resizing if one dimension is None.
    """
    width = op.resize_width
    height = op.resize_height
    resample_mode = op.resample_mode.upper()

    current_height, current_width = image.shape[:2]

    if width is None and height is None:
        return image # No resize specified
    
    # Calculate dimensions if one is None
    if width is None:
        if height is None or current_height == 0: # Avoid division by zero
            return image
        width = int(current_width * (height / current_height))
    elif height is None:
        if width is None or current_width == 0: # Avoid division by zero
            return image
        height = int(current_height * (width / current_width))
    
    # Check if target dimensions are zero, return original if so (or handle as error)
    if width <= 0 or height <= 0:
        print(f"Warning: Resize resulted in zero or negative dimension ({width}x{height}). Skipping resize.")
        return image

    if width == current_width and height == current_height:
        return image # No change needed

    flags = {
        "NEAREST": cv2.INTER_NEAREST, "BILINEAR": cv2.INTER_LINEAR,
        "BICUBIC": cv2.INTER_CUBIC, "LANCZOS4": cv2.INTER_LANCZOS4,
        "AREA": cv2.INTER_AREA
    }
    interp = flags.get(resample_mode, cv2.INTER_LANCZOS4)
    
    return cv2.resize(image, (width, height), interpolation=interp)

def apply_lut_operation(image: np.ndarray, op: XYBlendOperation, LUT_GENERATOR_FUNCTIONS: Dict[str, Callable[..., np.ndarray]]) -> np.ndarray:
    """
    Generates/loads a LUT and applies it to the image.
    This function now receives LUT_GENERATOR_FUNCTIONS map from the main processing logic.
    """
    lut_params = op.lut_params
    generated_lut: Optional[np.ndarray] = None

    try:
        if lut_params.lut_source == "generated":
            generator_func = LUT_GENERATOR_FUNCTIONS.get(lut_params.lut_generation_type)
            if generator_func:
                if lut_params.lut_generation_type == "linear":
                    generated_lut = generator_func(lut_params.linear_min_input, lut_params.linear_max_output)
                elif lut_params.lut_generation_type == "s_curve":
                    generated_lut = generator_func(lut_params.s_curve_contrast)
                elif lut_params.lut_generation_type == "gamma":
                    generated_lut = generator_func(lut_params.gamma_value)
                elif lut_params.lut_generation_type == "log":
                    generated_lut = generator_func(lut_params.log_param)
                elif lut_params.lut_generation_type == "exp":
                    generated_lut = generator_func(lut_params.exp_param)
                elif lut_params.lut_generation_type == "sqrt":
                    generated_lut = generator_func(lut_params.sqrt_param)
                elif lut_params.lut_generation_type == "rodbard":
                    generated_lut = generator_func(lut_params.rodbard_param)
                else: # Fallback for unknown generated types, or identity
                    generated_lut = lut_manager.get_default_z_lut() # Or raise error
            else:
                raise ValueError(f"Unknown LUT generation type function: {lut_params.lut_generation_type}")

        elif lut_params.lut_source == "file":
            if lut_params.fixed_lut_path and os.path.exists(lut_params.fixed_lut_path):
                generated_lut = lut_manager.load_lut(lut_params.fixed_lut_path)
            else:
                raise FileNotFoundError(f"LUT file not found: {lut_params.fixed_lut_path}")
        else:
            raise ValueError(f"Unknown LUT source: {lut_params.lut_source}")

    except (ValueError, FileNotFoundError) as e:
        print(f"Error for operation '{op.type}' (LUT): {e}. Using default identity LUT.")
        generated_lut = lut_manager.get_default_z_lut()
    except Exception as e:
        print(f"An unexpected error occurred during LUT generation/loading for operation '{op.type}': {e}. Using default identity LUT.")
        generated_lut = lut_manager.get_default_z_lut()

    if generated_lut is None:
        print(f"Error: No LUT could be determined for operation '{op.type}'. Skipping LUT application.")
        return image
    
    return lut_manager.apply_z_lut(image, generated_lut)


# --- Main Pipeline Processing Function ---
def process_xy_pipeline(
    image: np.ndarray, 
    pipeline_ops: List[XYBlendOperation],
    # ADD THESE ARGUMENTS to receive the registries from ui_components
    operations_registry_map: Dict[str, Any],
    lut_generator_functions_map: Dict[str, Callable[..., np.ndarray]]
) -> np.ndarray:
    """
    Applies the sequence of operations defined in the pipeline_ops list.
    Dispatches to the correct function based on the operation type.
    """
    processed_image = image.copy()

    if not pipeline_ops:
        return processed_image

    for op in pipeline_ops:
        op_type = op.type.lower()
        
        # Get the actual function object using a lookup map
        # This 'dispatch_map' should be defined within this module or passed in,
        # mapping the string name to the local function.
        # This avoids operations_registry having to import these functions.
        dispatch_map = {
            "gaussian_blur": apply_gaussian_blur,
            "bilateral_filter": apply_bilateral_filter,
            "median_blur": apply_median_blur,
            "unsharp_mask": apply_unsharp_mask,
            "resize": apply_resize,
            "apply_lut": apply_lut_operation,
            "none": lambda img, op: img # No-op function
        }
        
        processor_func = dispatch_map.get(op_type)
        
        if processor_func:
            try:
                # Special handling for apply_lut as it needs the LUT_GENERATOR_FUNCTIONS
                if op_type == "apply_lut":
                    processed_image = processor_func(processed_image, op, lut_generator_functions_map)
                else:
                    processed_image = processor_func(processed_image, op)
            except Exception as e:
                print(f"Error applying '{op_type}' operation: {e}. Skipping operation.")
                continue # Skip to next operation
        elif op_type != "none":
            print(f"Warning: Unknown or unsupported operation type '{op_type}'. Skipping.")
        
        # Ensure image is uint8 after each operation if it's not already,
        # to keep consistent for next operation and prevent overflow issues
        # (assuming operations return float sometimes).
        if processed_image.dtype != np.uint8:
            processed_image = np.clip(processed_image, 0, 255).astype(np.uint8)
    
    return processed_image